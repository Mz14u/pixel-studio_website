export default function PixelDivider() {
  return (
    <div className="w-full px-6">
      <div className="mx-auto max-w-6xl pixel-divider" />
    </div>
  )
}
